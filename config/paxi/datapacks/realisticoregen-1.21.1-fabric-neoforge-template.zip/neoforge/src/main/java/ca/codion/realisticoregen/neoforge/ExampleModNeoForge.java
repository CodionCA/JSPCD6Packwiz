package ca.codion.realisticoregen.neoforge;

import net.neoforged.fml.common.Mod;

import ca.codion.realisticoregen.ExampleMod;

@Mod(ExampleMod.MOD_ID)
public final class ExampleModNeoForge {
    public ExampleModNeoForge() {
        // Run our common setup.
        ExampleMod.init();
    }
}
